import React from "react";
import "./Footer.css";

class Footer extends React.Component{
    render() {
        return(
            <div className="footer">
                <div className="container">
                <p>Copyright © Your Website 2022</p>
                </div>
            </div>
        )
    }
}

export default Footer;